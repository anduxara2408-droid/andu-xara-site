// Correctif Firebase - Attendre le chargement
function waitForFirebase() {
    return new Promise((resolve) => {
        const check = () => {
            if (typeof firebase !== 'undefined' && firebase.apps) {
                resolve();
            } else {
                setTimeout(check, 100);
            }
        };
        check();
    });
}

async function initFirebaseSafe() {
    await waitForFirebase();
    
        if (typeof firebaseConfig !== 'undefined') {
            firebase.initializeApp(firebaseConfig);
            console.log('✅ Firebase initialisé');
        }
    }
    
    return firebase;
}

// Surcharger les fonctions problématiques
const originalAuthManager = window.authManager;

if (originalAuthManager) {
    const originalInit = originalAuthManager.init;
    originalAuthManager.init = async function() {
        await initFirebaseSafe();
        return originalInit.call(this);
    };
}

console.log('🔧 Correctif Firebase appliqué');
