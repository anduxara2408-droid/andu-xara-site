// Attendre que Firebase soit chargé
function waitForFirebase() {
    return new Promise((resolve) => {
        const check = () => {
            if (typeof firebase !== 'undefined' && firebase.apps) {
                resolve();
            } else {
                setTimeout(check, 100);
            }
        };
        check();
    });
}

// Initialiser Firebase de manière sécurisée
async function initFirebaseSafe() {
    await waitForFirebase();
    
    if (!firebase.apps.length) {
        if (typeof firebaseConfig !== 'undefined') {
            firebase.initializeApp(firebaseConfig);
            console.log('✅ Firebase initialisé');
        }
    }
    
    return firebase;
}

// Redéfinir les fonctions problématiques pour qu'elles attendent Firebase
const originalApplyPromo = window.applyPromoCode;
window.applyPromoCode = async function() {
    await initFirebaseSafe();
    return originalApplyPromo.apply(this, arguments);
};

console.log('🔧 Correctif Firebase appliqué');
