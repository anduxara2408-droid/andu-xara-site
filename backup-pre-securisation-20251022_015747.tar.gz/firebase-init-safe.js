// firebase-init-safe.js - Initialisation sécurisée de Firebase
console.log('🔥 Initialisation sécurisée Firebase...');

class FirebaseSafeInit {
    constructor() {
        this.ready = false;
        this.init();
    }

    async init() {
        try {
            // Attendre que Firebase soit complètement chargé
            await this.waitForFirebase();
            
            // Initialiser l'application
            if (!firebase.apps.length) {
                if (typeof firebaseConfig !== 'undefined') {
                    firebase.initializeApp(firebaseConfig);
                    console.log('✅ Firebase initialisé avec succès');
                } else {
                    throw new Error('Configuration Firebase non trouvée');
                }
            }
            
            this.ready = true;
            console.log('🎉 Firebase prêt à être utilisé');
            
            // Déclencher un événement global
            window.dispatchEvent(new CustomEvent('firebaseReady'));
            
        } catch (error) {
            console.error('❌ Erreur initialisation Firebase:', error);
        }
    }

    waitForFirebase() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50; // 5 secondes max
            
            const checkFirebase = () => {
                attempts++;
                
                if (typeof firebase !== 'undefined' && 
                    typeof firebase.initializeApp === 'function') {
                    resolve();
                    return;
                }
                
                if (attempts >= maxAttempts) {
                    reject(new Error('Firebase non chargé après 5 secondes'));
                    return;
                }
                
                setTimeout(checkFirebase, 100);
            };
            
            checkFirebase();
        });
    }

    isReady() {
        return this.ready;
    }

    getFirebase() {
        if (!this.ready) {
            throw new Error('Firebase non prêt');
        }
        return firebase;
    }
}

// Initialisation globale
window.firebaseInit = new FirebaseSafeInit();

// Fonction utilitaire pour attendre Firebase
window.waitForFirebase = function() {
    return new Promise((resolve) => {
        if (window.firebaseInit && window.firebaseInit.isReady()) {
            resolve(window.firebaseInit.getFirebase());
        } else {
            window.addEventListener('firebaseReady', () => {
                resolve(window.firebaseInit.getFirebase());
            });
        }
    });
};
