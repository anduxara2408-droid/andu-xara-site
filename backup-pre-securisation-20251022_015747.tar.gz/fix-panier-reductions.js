// fix-panier-reductions.js - Correction panier reductions.html
console.log('🔧 Application correctif panier reductions.html');

function initPanierReductions() {
    console.log('🔄 Initialisation panier reductions.html');
    
    if (typeof panierUnifie === 'undefined') {
        console.error('❌ panierUnifie non trouvé, chargement manuel...');
        
        window.panierUnifie = {
            panier: JSON.parse(localStorage.getItem('anduxara_cart')) || [],
            codePromoActif: JSON.parse(localStorage.getItem('anduxara_active_promo')) || null,
            
            togglePanier: function() {
                const panier = document.getElementById('floating-cart');
                if (panier) {
                    panier.classList.toggle('open');
                    console.log('🛒 Panier togglé:', panier.classList.contains('open'));
                    if (panier.classList.contains('open')) {
                        this.mettreAJourAffichagePanier();
                    }
                }
            },
            
            fermerPanier: function() {
                const panier = document.getElementById('floating-cart');
                if (panier) {
                    panier.classList.remove('open');
                }
            },
            
            mettreAJourAffichagePanier: function() {
                console.log('📊 Mise à jour affichage panier');
                this.mettreAJourCompteur();
                this.mettreAJourListeArticles();
                this.mettreAJourTotal();
            },
            
            mettreAJourCompteur: function() {
                const badge = document.getElementById('cart-badge-floating');
                if (badge) {
                    const totalItems = this.panier.reduce((sum, item) => sum + item.quantity, 0);
                    badge.textContent = totalItems;
                }
            },
            
            mettreAJourListeArticles: function() {
                const container = document.getElementById('cart-items-floating');
                if (!container) return;
                
                if (this.panier.length === 0) {
                    container.innerHTML = '<div class="empty-cart-floating">Panier vide</div>';
                    return;
                }
                
                container.innerHTML = this.panier.map((item, index) => {
                    const prixUnitaire = item.promoPrice || item.price;
                    const prixTotal = prixUnitaire * item.quantity;
                    const prixOriginal = item.price * item.quantity;
                    
                    return '<div class="cart-item-floating">' +
                        '<div class="cart-item-info">' +
                        '<h4>' + item.name + '</h4>' +
                        '<p>Quantité: ' + item.quantity + '</p>' +
                        (this.codePromoActif ? 
                            '<p style="color: #27ae60; font-size: 0.7rem;">🎯 Promo: -' + this.codePromoActif.discount + '%</p>' : '') +
                        '<button class="remove-item" onclick="panierUnifie.retirerProduit(' + index + ')">Retirer</button>' +
                        '</div>' +
                        '<div class="cart-item-price">' +
                        (this.codePromoActif ? 
                            '<div style="text-decoration: line-through; color: #888; font-size: 0.7rem;">' + 
                            prixOriginal.toFixed(0) + ' MRU</div>' : '') +
                        '<div style="color: #e60023; font-weight: bold;">' +
                        prixTotal.toFixed(0) + ' MRU</div>' +
                        '</div>' +
                        '</div>';
                }).join('');
            },
            
            mettreAJourTotal: function() {
                const totalElement = document.getElementById('cart-total-floating');
                if (!totalElement) return;
                
                const total = this.panier.reduce((sum, item) => {
                    return sum + ((item.promoPrice || item.price) * item.quantity);
                }, 0);
                
                totalElement.textContent = total.toFixed(0);
            },
            
            retirerProduit: function(index) {
                if (this.panier[index]) {
                    this.panier.splice(index, 1);
                    localStorage.setItem('anduxara_cart', JSON.stringify(this.panier));
                    this.mettreAJourAffichagePanier();
                }
            },
            
            appliquerCodePromo: function(code, reduction) {
                this.codePromoActif = { code: code, discount: reduction };
                localStorage.setItem('anduxara_active_promo', JSON.stringify(this.codePromoActif));
                
                this.panier.forEach(item => {
                    item.promoPrice = Math.round(item.price * (1 - reduction / 100));
                });
                
                localStorage.setItem('anduxara_cart', JSON.stringify(this.panier));
                this.mettreAJourAffichagePanier();
                console.log('🎉 Code promo appliqué:', code, reduction + '%');
            },
            
            retirerCodePromo: function() {
                this.codePromoActif = null;
                localStorage.removeItem('anduxara_active_promo');
                
                this.panier.forEach(item => {
                    item.promoPrice = item.price;
                });
                
                localStorage.setItem('anduxara_cart', JSON.stringify(this.panier));
                this.mettreAJourAffichagePanier();
            }
        };
    }
    
    initEvenements();
}

function initEvenements() {
    const toggleBtn = document.querySelector('.cart-toggle');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (window.panierUnifie) {
                window.panierUnifie.togglePanier();
            }
        });
    }
    
    document.addEventListener('click', function(e) {
        const panier = document.getElementById('floating-cart');
        const toggle = document.querySelector('.cart-toggle');
        
        if (panier && panier.classList.contains('open') &&
            !panier.contains(e.target) && 
            !toggle.contains(e.target)) {
            if (window.panierUnifie) {
                window.panierUnifie.fermerPanier();
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        initPanierReductions();
    }, 500);
});

function toggleFloatingCart() {
    if (window.panierUnifie) {
        window.panierUnifie.togglePanier();
    }
}

function closeFloatingCart() {
    if (window.panierUnifie) {
        window.panierUnifie.fermerPanier();
    }
}

function processerPaiement() {
    if (window.panierUnifie && window.panierUnifie.panier.length > 0) {
        const total = window.panierUnifie.panier.reduce((sum, item) => 
            sum + ((item.promoPrice || item.price) * item.quantity), 0);
        
        const message = 'Bonjour ! Je souhaite commander :\\n\\n' +
            window.panierUnifie.panier.map(item => 
                item.name + ' (x' + item.quantity + ') - ' + ((item.promoPrice || item.price) * item.quantity) + ' MRU'
            ).join('\\n') +
            '\\n\\n💰 Total : ' + total + ' MRU';
        
        window.open('https://wa.me/22249037697?text=' + encodeURIComponent(message), '_blank');
    } else {
        alert('Panier vide !');
    }
}
