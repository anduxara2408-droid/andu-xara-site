// fix-panier-reductions.js - Correction panier reductions.html
console.log('🔧 Application correctif panier reductions.html');

function initPanierReductions() {
    console.log('🔄 Initialisation panier reductions.html');
    
    if (typeof panierUnifie === 'undefined') {
        console.error('❌ panierUnifie non trouvé, chargement manuel...');
        
        window.panierUnifie = {
            panier: JSON.parse(localStorage.getItem('anduxara_cart')) || [],
            codePromoActif: JSON.parse(localStorage.getItem('anduxara_active_promo')) || null,
            
            togglePanier: function() {
                const panier = document.getElementById('floating-cart');
                if (panier) {
                    panier.classList.toggle('open');
                    console.log('🛒 Panier togglé:', panier.classList.contains('open'));
                    if (panier.classList.contains('open')) {
                        this.mettreAJourAffichagePanier();
                    }
                }
            },
            
            fermerPanier: function() {
                const panier = document.getElementById('floating-cart');
                if (panier) {
                    panier.classList.remove('open');
                }
            },
