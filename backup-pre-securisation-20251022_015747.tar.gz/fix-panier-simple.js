// Correctif panier reductions.html - Version simplifiée
console.log('🔧 Correctif panier chargé');

// Système panier basique pour reductions.html
window.panierSimple = {
    init: function() {
        console.log('🔄 Initialisation panier simple');
        this.chargerPanier();
        this.initEvents();
    },

    chargerPanier: function() {
        this.panier = JSON.parse(localStorage.getItem('anduxara_cart')) || [];
        this.codePromo = JSON.parse(localStorage.getItem('anduxara_active_promo')) || null;
        this.updateBadge();
    },

    initEvents: function() {
        const toggleBtn = document.querySelector('.cart-toggle');
        if (toggleBtn) {
            toggleBtn.onclick = (e) => {
                e.stopPropagation();
                this.togglePanier();
            };
        }

        // Fermer en cliquant à l'extérieur
        document.addEventListener('click', (e) => {
            const panier = document.getElementById('floating-cart');
            const toggle = document.querySelector('.cart-toggle');
            if (panier && panier.classList.contains('open') && 
                this.fermerPanier();
            }
        });
    },

    togglePanier: function() {
        const panier = document.getElementById('floating-cart');
        if (panier) {
            panier.classList.toggle('open');
            console.log('🛒 Panier:', panier.classList.contains('open') ? 'ouvert' : 'fermé');
            if (panier.classList.contains('open')) {
                this.afficherPanier();
            }
        }
    },

    fermerPanier: function() {
        const panier = document.getElementById('floating-cart');
        if (panier) {
            panier.classList.remove('open');
        }
    },

    afficherPanier: function() {
        this.updateBadge();
        this.updateItems();
        this.updateTotal();
    },

    updateBadge: function() {
        const badge = document.getElementById('cart-badge-floating');
        if (badge) {
            const total = this.panier.reduce((sum, item) => sum + item.quantity, 0);
            badge.textContent = total;
        }
    },

    updateItems: function() {
        const container = document.getElementById('cart-items-floating');

        if (this.panier.length === 0) {
            container.innerHTML = '<div class="empty-cart-floating">Panier vide</div>';
            return;
        }

        let html = '';
        this.panier.forEach((item, index) => {
            const prix = (item.promoPrice || item.price) * item.quantity;
            const prixOrig = item.price * item.quantity;

            html += '<div class="cart-item-floating">';
            html += '<div class="cart-item-info">';
            html += '<h4>' + item.name + '</h4>';
            html += '<p>Quantité: ' + item.quantity + '</p>';
            if (this.codePromo) {
                html += '<p style="color:#27ae60;font-size:0.7rem;">🎯 Promo: -' + this.codePromo.discount + '%</p>';
            }
            html += '<button class="remove-item" onclick="panierSimple.supprimer(' + index + ')">Retirer</button>';
            html += '</div>';
            html += '<div class="cart-item-price">';
            if (this.codePromo) {
                html += '<div style="text-decoration:line-through;color:#888;font-size:0.7rem;">' + prixOrig.toFixed(0) + ' MRU</div>';
            }
            html += '<div style="color:#e60023;font-weight:bold;">' + prix.toFixed(0) + ' MRU</div>';
            html += '</div>';
            html += '</div>';
        });

        container.innerHTML = html;
    },

    updateTotal: function() {
        const totalEl = document.getElementById('cart-total-floating');

        const total = this.panier.reduce((sum, item) => {
            return sum + ((item.promoPrice || item.price) * item.quantity);
        }, 0);

        totalEl.textContent = total.toFixed(0);
    },

    supprimer: function(index) {
        if (this.panier[index]) {
            this.panier.splice(index, 1);
            localStorage.setItem('anduxara_cart', JSON.stringify(this.panier));
            this.afficherPanier();
        }
    }
};

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        if (window.panierSimple) {
            window.panierSimple.init();
        }
    }, 1000);
});

// Fonctions globales pour compatibilité
function toggleFloatingCart() {
    if (window.panierSimple) {
        window.panierSimple.togglePanier();
    }
}

function closeFloatingCart() {
    if (window.panierSimple) {
        window.panierSimple.fermerPanier();
    }
}

function processerPaiement() {
    if (window.panierSimple && window.panierSimple.panier.length > 0) {
        const total = window.panierSimple.panier.reduce((sum, item) => 
            sum + ((item.promoPrice || item.price) * item.quantity), 0);

        const produits = window.panierSimple.panier.map(item => 
            item.name + ' (x' + item.quantity + ') - ' + ((item.promoPrice || item.price) * item.quantity) + ' MRU'
        ).join('\\n');

        const message = 'Bonjour ! Je souhaite commander :\\n\\n' + produits + '\\n\\n💰 Total : ' + total + ' MRU';

        window.open('https://wa.me/22249037697?text=' + encodeURIComponent(message), '_blank');
    } else {
    }
}
